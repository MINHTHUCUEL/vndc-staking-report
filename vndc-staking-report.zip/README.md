# VNDC Staking Report
Đồ án môn học Công nghệ Blockchain: Mô phỏng chức năng staking của VNDC.
