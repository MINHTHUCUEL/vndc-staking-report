# Báo cáo Đồ án Blockchain
## Đề tài: VNDC Stablecoin và Mô hình Staking

### 1. Tính cấp thiết
(Phân tích từ phần trước về sự cần thiết, bối cảnh VNDC trong thị trường blockchain Việt Nam...)

### 2. Ưu và nhược điểm
(Ưu điểm: staking nhận lãi, chuyển đổi nhanh, bảo hiểm ký quỹ. Nhược điểm: rủi ro thị trường, chưa có pháp lý rõ ràng...)

### 3. Công nghệ áp dụng
- Blockchain: Ethereum ERC-20, Binance BEP-2
- Smart Contract: Solidity
- Tích hợp frontend: HTML/CSS/JS

### 4. Mã nguồn Smart Contract (trích)
(đã đưa vào file riêng: `VNDCStaking.sol`)
